// docs/js/app.js
import { auth } from "./firebase-init.js";
import { onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";

const $ = (id) => document.getElementById(id);

const q = $("q");
const btnPremium = $("btn-premium");
const btnStudio = $("btn-studio");
const btnCurso = $("btn-curso");
const btnCopy = $("btn-copy");
const previewTarget = $("preview-target");
const status = $("status");
const dlg = $("dlg");

function setStatus(msg){ if(status) status.textContent = msg; }

function clean(s){
  return (s || "").toString().trim().replace(/\s+/g," ").slice(0,140);
}

function syncPreview(){
  const v = clean(q?.value);
  if(previewTarget) previewTarget.textContent = v || "—";
}

q?.addEventListener("input", syncPreview);
syncPreview();

let isLogged = false;
onAuthStateChanged(auth, (user) => { isLogged = !!user; });

btnStudio?.addEventListener("click", () => {
  // tu link real (lo dejaste antes)
  window.open("https://9000-firebase-studio-1760256504173.cluster-udxxdyopu5c7cwhhtg6mmadhvs.cloudworkstations.dev", "_blank", "noopener");
});

btnCurso?.addEventListener("click", () => {
  // si luego haces cursos.html, aquí lo conectas
  setStatus("curso: en ruta. (conecta /cursos.html cuando esté listo)");
  window.location.hash = "#curso";
});

btnCopy?.addEventListener("click", async () => {
  try{
    await navigator.clipboard.writeText(window.location.href);
    setStatus("link copiado.");
  }catch{
    setStatus("no se pudo copiar (permiso del navegador).");
  }
});

btnPremium?.addEventListener("click", () => {
  const target = clean(q?.value);

  if(!target){
    setStatus("pon un objetivo primero.");
    q?.focus();
    return;
  }

  // guardamos el objetivo para el siguiente paso / futura página de checkout
  localStorage.setItem("bauzagpt_target", target);
  localStorage.setItem("bauzagpt_ts", new Date().toISOString());

  if(!isLogged){
    setStatus("inicia sesión para guardar tu caso.");
    dlg?.showModal();
    return;
  }

  // mvp: por ahora solo confirma y te manda al panel / builder
  setStatus("ok: caso creado. abre tu panel para armar el pdf.");
  window.open("https://9000-firebase-studio-1760256504173.cluster-udxxdyopu5c7cwhhtg6mmadhvs.cloudworkstations.dev", "_blank", "noopener");
});

$("y").textContent = new Date().getFullYear().toString();
