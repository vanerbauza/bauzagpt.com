const firebaseConfig = {
  apiKey: "AIzaSyD3a7cv735RQPYsXMdn4KWQ-NDugL7WyfI",
  authDomain: "studio-6473341422-75630.firebaseapp.com",
  projectId: "studio-6473341422-75630",
  storageBucket: "studio-6473341422-75630.firebasestorage.app",
  messagingSenderId: "240684953453",
  appId: "1:240684953453:web:6027f3b025c9ee22e8b464"
};