#!/usr/bin/env python3
"""
dork_runner.py (parcheado)
Uso: python dork_runner.py --dork "tu dork" --outdir outputs --max 25
Mejoras:
 - Usa GET a duckduckgo.com/html y fallback a lite.duckduckgo.com/lite
 - Maneja 403 sin romper (retorna lista vacía)
 - Añade logging simple por consola
"""
import argparse
import requests
from bs4 import BeautifulSoup
import json, os, csv, time
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from datetime import datetime

HEADERS = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) BauzaBot/1.0"}

def duckduck_search(query, max_results=20, sleep_on_403=2):
    """Intenta buscar en DuckDuckGo con fallback y devuelve lista de dicts."""
    # primary: duckduckgo html endpoint (GET)
    urls_to_try = [
        ("https://duckduckgo.com/html/", {"q": query}),
        ("https://lite.duckduckgo.com/lite/", {"q": query}),
    ]

    for url, params in urls_to_try:
        try:
            r = requests.get(url, params=params, headers=HEADERS, timeout=15)
        except Exception as e:
            print(f"[!] Error conectando a {url}: {e}")
            continue

        if r.status_code == 403:
            print(f"[!] 403 Forbidden en {url}, intentando siguiente fallback...")
            time.sleep(sleep_on_403)
            continue

        if r.status_code != 200:
            print(f"[!] Estado {r.status_code} en {url}, intentando siguiente...")
            time.sleep(1)
            continue

        # parse HTML (compatible con /html/ y /lite/)
        soup = BeautifulSoup(r.text, "html.parser")
        results = []

        # duckduckgo.com/html uses a.result__a; lite uses <a> in <div class="result"> etc.
        # Buscamos de forma amplia:
        anchors = soup.select("a.result__a") or soup.select("a")
        seen = set()
        for a in anchors:
            href = a.get("href") or a.get("data-href") or ""
            title = a.get_text().strip()
            # snippet attempt
            snippet = ""
            parent = a.find_parent()
            if parent:
                s_el = parent.select_one(".result__snippet") or parent.select_one("div")
                if s_el:
                    snippet = s_el.get_text().strip()
            # basic filter
            if not href:
                continue
            if href in seen:
                continue
            seen.add(href)
            results.append({"title": title, "url": href, "snippet": snippet})
            if len(results) >= max_results:
                break

        print(f"[+] {len(results)} resultados desde {url}")
        return results

    # si llegamos aquí, todos los endpoints fallaron
    print("[!] Todos los endpoints de DuckDuckGo fallaron o devolvieron 403. Devuelto 0 resultados.")
    return []

def save_json(path, data):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def save_csv(path, data):
    if not data:
        return
    keys = data[0].keys()
    with open(path, "w", newline='', encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        writer.writerows(data)

def make_pdf(path, title, rows):
    c = canvas.Canvas(path, pagesize=letter)
    w, h = letter
    c.setFont("Helvetica-Bold", 14)
    c.drawString(40, h-50, title)
    c.setFont("Helvetica", 10)
    c.drawString(40, h-70, f"Fecha: {datetime.now().isoformat()}")
    y = h-100
    for i, r in enumerate(rows, 1):
        text = f"{i}. {r.get('title','')} — {r.get('url','')}"
        c.drawString(40, y, text[:120])
        y -= 14
        if y < 60:
            c.showPage()
            y = h-60
    c.save()

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--dork", required=True, help="Query / dork a ejecutar")
    p.add_argument("--outdir", default="../outputs", help="Carpeta de salida relativa a este script")
    p.add_argument("--max", type=int, default=20, help="Máx resultados")
    args = p.parse_args()

    outdir = os.path.abspath(args.outdir)
    os.makedirs(outdir, exist_ok=True)
    for sub in ("json","csv","reports"):
        os.makedirs(os.path.join(outdir, sub), exist_ok=True)

    ts = int(datetime.now().timestamp())
    json_path = os.path.join(outdir, "json", f"dork_{ts}.json")
    csv_path = os.path.join(outdir, "csv", f"dork_{ts}.csv")
    pdf_path = os.path.join(outdir, "reports", f"dork_{ts}.pdf")

    print("[*] Ejecutando dork:", args.dork)
    rows = duckduck_search(args.dork, max_results=args.max)
    print(f"[+] {len(rows)} resultados obtenidos")

    save_json(json_path, rows)
    save_csv(csv_path, rows)
    make_pdf(pdf_path, f"Reporte Dork: {args.dork}", rows)

    print("[*] Guardado JSON:", json_path)
    print("[*] Guardado CSV:", csv_path)
    print("[*] Guardado PDF:", pdf_path)

if __name__ == "__main__":
    main()
